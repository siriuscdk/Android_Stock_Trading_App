package com.example.stocks;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class newsadapter extends  RecyclerView.Adapter<newsadapter.ViewHolder>{
    // Initialize activity and array list
    private Activity activity;
    ArrayList<ArrayList<String>> arrayListGroup;

    //Create constructor
    newsadapter(Activity activity, ArrayList<ArrayList<String>> arrayListGroup){
        this.activity=activity;
        this.arrayListGroup=arrayListGroup;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //View view= LayoutInflater.from(parent.getContext())
        //        .inflate(R.layout.list_row_group, parent, false);
        //return new newsadapter2.ViewHolder(view);
        View v;
        ViewHolder vh;

        switch (viewType) {
            case 0: //This would be the header view in my Recycler
                v = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.new1, parent, false);
                vh = new ViewHolder(v);
                return  vh;
            default: //This would be the normal list with the pictures of the places in the world
                v = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.new2, parent, false);
                vh = new ViewHolder(v);
                return vh;
        }
    }

    @Override
    public int getItemViewType(int position) {
        int viewType = 1; //Default is 1
        if (position == 0) viewType = 0; //if zero, it will be a header view
        return viewType;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Set group name on TextView
        holder.newstitle.setText(arrayListGroup.get(position).get(1));
        holder.newstitle.setTextColor(Color.BLACK);
        //holder.newstitle2.setText(arrayListGroup.get(position));
        holder.newstitle3.setText(arrayListGroup.get(position).get(0));

        //String url="https://i.insider.com/5f98dece6f5b310011723c5c?width=1200&format=jpeg";
        String imgurl=arrayListGroup.get(position).get(2);
        String url=arrayListGroup.get(position).get(3);

        Glide.with(activity)
                .load(imgurl)
                .placeholder(R.drawable.ic_launcher_foreground)
                .centerCrop()
                .into(holder.imgview);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // open another activity on item click
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                activity.startActivity(browserIntent);
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                //Create dialog
                Dialog dialog=new Dialog(activity);
                dialog.setContentView(R.layout.news_dialog);

                ImageView dialogimgview=dialog.findViewById(R.id.newsdialogimg);
                TextView dialogtext=dialog.findViewById(R.id.newsdialogtext);
                Button dialogtwbutton=dialog.findViewById(R.id.twitterbutton);
                Button dialogchrombutton=dialog.findViewById(R.id.chromebutton);

                Glide.with(activity)
                        .load(imgurl)
                        .placeholder(R.drawable.ic_launcher_foreground)
                        .centerCrop()
                        .into(dialogimgview);

                dialogtext.setText(arrayListGroup.get(position).get(1));
                dialogtext.setTextColor(Color.BLACK);
                dialogtwbutton.setBackgroundColor(Color.WHITE);
                dialogchrombutton.setBackgroundColor(Color.WHITE);

                dialogtwbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // open another activity on item click
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=Check%20out%20this%20Link%20"+url+"%20%23CSCI571StockApp"));
                        activity.startActivity(browserIntent);
                    }
                });

                dialogchrombutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // open another activity on item click
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        activity.startActivity(browserIntent);
                    }
                });


                dialog.show();
                return false;
            }
        });


    }

    @Override
    public int getItemCount() {
        return arrayListGroup.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // Initialize variable
        TextView newstitle;
        //TextView newstitle2;
        TextView newstitle3;
        //RecyclerView newsmember;
        ImageView imgview;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            newstitle=itemView.findViewById(R.id.news_title);
            //newstitle2=itemView.findViewById(R.id.news_title2);
            newstitle3=itemView.findViewById(R.id.news_title3);
            //newsmember=itemView.findViewById(R.id.news_member);
            imgview=itemView.findViewById(R.id.imageView);
        }
    }
}
