package com.example.stocks;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class poadapter extends RecyclerView.Adapter<poadapter.ViewHolder> {
    //Initialize activity and array list
    private Activity activity;
    ArrayList<ArrayList<String>> arrayListGroup;

    //constructor
    poadapter(Activity activity, ArrayList<ArrayList<String>> arrayListGroup){
        this.activity=activity;
        this.arrayListGroup=arrayListGroup;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.po_item, parent, false);
        return new poadapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String curticker=arrayListGroup.get(position).get(0);
        holder.poticker.setText(curticker);
        holder.polast.setText(arrayListGroup.get(position).get(2));
        holder.ponumshares.setText(arrayListGroup.get(position).get(1));

        double change=Double.parseDouble(arrayListGroup.get(position).get(3));
        String changestr=String.valueOf(Math.abs(change));
        holder.pochange.setText(changestr);
        if (change>0){
            holder.pochange.setTextColor(Color.parseColor("#319C5E"));
            holder.pochange.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_up_trend, 0, 0, 0);
        }
        else if (change<0){
            holder.pochange.setTextColor(Color.parseColor("#9B4049"));
            holder.pochange.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_down_trend, 0, 0, 0);
        };

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // open another activity on item click
                Intent intent= new Intent(activity, detailactivity.class);
                intent.putExtra("ticker",curticker);
                //startActivity(intent);
                activity.startActivityForResult(intent, 2);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayListGroup.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //initialize variables
        TextView poticker;
        TextView polast;
        TextView ponumshares;
        TextView pochange;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            poticker=itemView.findViewById(R.id.po_ticker);
            polast=itemView.findViewById(R.id.poitem_lastprice);
            ponumshares=itemView.findViewById(R.id.poitem_numshares);
            pochange=itemView.findViewById(R.id.positem_change);

        }
    }
}
