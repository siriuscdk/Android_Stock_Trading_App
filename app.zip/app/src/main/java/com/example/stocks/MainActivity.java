package com.example.stocks;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
//import android.widget.SearchView;

import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import android.os.Handler;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.RequestFuture;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import java.time.LocalDateTime;  // Import the LocalDateTime class
import java.time.format.DateTimeFormatter;  // Import the DateTimeFormatter class


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import it.xabaras.android.recyclerview.swipedecorator.RecyclerViewSwipeDecorator;

public class MainActivity extends AppCompatActivity {

    private static DecimalFormat df = new DecimalFormat("0.00");

    private androidx.appcompat.widget.Toolbar toolbar;

    //private static final String[] COUNTRIES = new String[] { "Belgium", "France", "France_", "Italy", "Germany", "Spain" };

    SearchView.SearchAutoComplete searchAutoComplete;
    private JSONArray autocomdata;
    //List<String> dataArr = new ArrayList<String>();
    //ArrayList<String> newdata = new ArrayList<>();

    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    private Handler handler;
    AutoSuggestAdapter  newsAdapter;

    View mainLayout1;
    View mainLayout2;

    TextView dateandtime;
    TextView mainfooter;

    ArrayList<JSONObject> favstoragedata;
    ArrayList<String> favtickers;
    JSONArray favinfo;
    HashMap<String, String> favtickercompname;


    RecyclerView favGroup;
    ArrayList<ArrayList<String>> favinfoGroup;
    LinearLayoutManager favlayoutManagerGroup;
    favadapter favadapter;
    String favalltickersstr;


    JSONArray poinfo;
    ArrayList<JSONObject> pofoliostoragedata;
    ArrayList<String> potickers;
    HashMap<String, Double> potickerquantity;
    String poalltickersstr;

    RecyclerView poGroup;
    ArrayList<ArrayList<String>> poinfoGroup;
    LinearLayoutManager polayoutManagerGroup;
    poadapter poadapter;

    ItemTouchHelper itemTouchHelper;
    ItemTouchHelper poitemTouchHelper;

    double networth;
    float cash;
    TextView networthtext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_Stocks);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("myTag", "This is my message");
        // get toolbar
        toolbar=findViewById(R.id.myToolbar);
        toolbar.setTitle("Stocks");
        setSupportActionBar(toolbar);

        // control spinner
        mainLayout1=findViewById(R.id.mainLayout1);
        mainLayout2=findViewById(R.id.mainLayout2);

        //mainLayout1.setVisibility(View.VISIBLE);
        //mainLayout2.setVisibility(View.INVISIBLE);

        itemTouchHelper=new ItemTouchHelper(simpleCallback);
        poitemTouchHelper=new ItemTouchHelper(posimpleCallback);

        try {
            loadmainact();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        //get footer
        mainfooter=(TextView)findViewById(R.id.mainfooter);
        mainfooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiingo.com"));
                startActivity(browserIntent);
            }

        });

        //refresh every 15 seconds
        Thread t=new Thread(){
            @Override
            public void run(){
                while (!isInterrupted()){

                    try {
                        Thread.sleep(30000);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    loadmainactcon();

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        t.start();


    }

    @SuppressLint("RestrictedApi")
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu, menu);



        //MenuItem searchItem = menu.findItem(R.id.search);
        SearchView searchView=(SearchView) menu.findItem(R.id.search).getActionView();
        //final AppCompatAutoCompleteTextView autoCompleteTextView =findViewById(R.id.search);



        // Get SearchView autocomplete object.
        searchAutoComplete = (SearchView.SearchAutoComplete)  searchView.findViewById(androidx.appcompat.R.id.search_src_text);

        // Create a new ArrayAdapter and add data to search auto complete object.
        //String dataArr[] = {"Apple" , "Amazon" , "Amd", "Microsoft", "Microwave", "MicroNews", "Intel", "Intelligence"};
        //List<String> dataArr = new ArrayList<String>();
        //dataArr.add("Apple");
        //ArrayAdapter<String> newsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, dataArr);

        //newsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, dataArr);
        newsAdapter = new AutoSuggestAdapter(this, android.R.layout.simple_dropdown_item_1line);
        searchAutoComplete.setThreshold(3);
        searchAutoComplete.setAdapter(newsAdapter);



        // Listen to search view item on click event.
        searchAutoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int itemIndex, long id) {
                String queryString=(String)adapterView.getItemAtPosition(itemIndex);
                searchAutoComplete.setText("" + queryString);
                //Toast.makeText(ActionBarSearchActivity.this, "you clicked " + queryString, Toast.LENGTH_LONG).show();
            }
        });

        searchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        // redirrect to another activity
                        // progress spinner
                        //send http req
                        String sendticker;
                        if (query.indexOf("-")!=-1){
                            sendticker=query.substring(0,query.indexOf("-")-1);
                        }
                        else {
                            sendticker=query;
                        }
                        Log.d("sendmysearch", sendticker);

                        Log.d("sendmyquery", query);
                        Intent intent= new Intent(MainActivity.this, detailactivity.class);
                        intent.putExtra("ticker",sendticker);
                        //startActivity(intent);
                        startActivityForResult(intent, 2);

                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {

                        handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                        handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                                AUTO_COMPLETE_DELAY);

                        //Log.d("sendmyhttpreq", newText);
                        //autocompletehttpreq("https://siriusangularnojsapp.wl.r.appspot.com/autocomplete/"+newText);

                        //Log.d("mycurinput", newText);
                        return false;
                    }
                }
        );

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
                        //makeApiCall(searchAutoComplete.getText().toString());
                        autocompletehttpreq("https://siriusangularnojsapp.wl.r.appspot.com/autocomplete/"+searchAutoComplete.getText().toString());
                    }
                }
                return false;
            }
        });

        return true;
    }

    // Call Back method  to get the change from other Activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode==2)
        {
            //String message=data.getStringExtra("MESSAGE");
            //textView1.setText(message);
            try {
                loadmainact();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void autocompletehttpreq(String requrl){

       RequestQueue queue = Volley.newRequestQueue(this);

       // prepare the Request
       JsonArrayRequest getRequest = new JsonArrayRequest(Request.Method.GET, requrl, null,
               new Response.Listener<JSONArray>()
               {
                   @Override
                   public void onResponse(JSONArray response) {
                       // display response
                       //dataArr.clear();
                       //newsAdapter.clear();

                       Log.d("Response", response.toString());
                       autocomdata=response;
                       ArrayList<String> newdata = new ArrayList<>();
                       //newdata = new ArrayList<>();
                       //newdata.clear();

                       for (int i=0;i<autocomdata.length();i++){
                           try {
                               JSONObject object=autocomdata.getJSONObject(i);
                               //dataArr.add(object.getString("ticker")+" - "+object.getString("name"));
                               newdata.add(object.getString("ticker")+" - "+object.getString("name"));
                               //System.out.println(newdata.get(i));

                           } catch (JSONException e) {
                               e.printStackTrace();
                           }
                       }

                       //newsAdapter.clear();
                       //newsAdapter.addAll(newdata);
                       //newsAdapter.notifyDataSetChanged();
                       newsAdapter.setData(newdata);
                       newsAdapter.notifyDataSetChanged();

                       //dataArr.clear();

                   }
               },
               new Response.ErrorListener()
               {
                   @Override
                   public void onErrorResponse(VolleyError error) {
                       Log.d("Error.Response", error.toString());
                   }
               }
       );
       // add it to the RequestQueue
       queue.add(getRequest);

    }

    private void loadmainact() throws JSONException {

        mainLayout1.setVisibility(View.VISIBLE);
        mainLayout2.setVisibility(View.INVISIBLE);
        loadmainactcon();
    }

    private void loadmainactcon() throws JSONException {
        // set today's date
        //String curdatestr =new Date());
        dateandtime=(TextView)findViewById(R.id.dateandtime);

        LocalDateTime myDateObj = LocalDateTime.now();
        System.out.println("Before Formatting: " + myDateObj);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MMMM dd, yyyy");

        String formattedDate = myDateObj.format(myFormatObj);
        System.out.println("After Formatting: " + formattedDate);
        dateandtime.setText(formattedDate);

        // Get fav tickers from local storage
        //clearfavData();
        loadfavData();
        System.out.println("main:"+favstoragedata);
        favtickercompname = new HashMap<String, String>();
        // compose url
        favtickers=new ArrayList<String>();
        for (int i=0;i<favstoragedata.size();i++){
            JSONObject curobj=favstoragedata.get(i);
            favtickers.add(curobj.getString("ticker"));

            favtickercompname.put(curobj.getString("ticker"), curobj.getString("companyname"));
        }

        // initialize net worth
        //loadinitcash();
        loadcash();

        // load portfolio data
        //clearpoData();
        loadpoData();
        potickerquantity = new HashMap<String, Double>();
        // compose portfolio req url
        potickers=new ArrayList<String>();
        for (int i=0;i<pofoliostoragedata.size();i++){
            JSONObject curobj=pofoliostoragedata.get(i);
            potickers.add(curobj.getString("ticker"));

            potickerquantity.put(curobj.getString("ticker"), curobj.getDouble("quantity"));
        }

        poalltickersstr=android.text.TextUtils.join(",", potickers);
        //calculate net worth


        favalltickersstr=android.text.TextUtils.join(",", favtickers);

        //if (favtickers.size()!=0 || pofoliostoragedata.size()!=0){
        String requrl="https://siriusangularnojsapp.wl.r.appspot.com/price/"+favalltickersstr;
        System.out.println("url:"+requrl);

        favinfohttpreq(requrl);
        //}
        //else {
        //    mainLayout1.setVisibility(View.INVISIBLE);
        //    mainLayout2.setVisibility(View.VISIBLE);
        //}


    }



    private void loadinitcash() {
        cash=20000;
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        //Gson gson = new Gson();
        //String json = gson.toJson(cash);
        editor.putFloat("cash", cash);
        //editor.putString(dtype, json);
        editor.apply();

    }

    private void loadcash() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        cash=sharedPreferences.getFloat("cash", 0.0f);
        //if (cash == 0) {
        //favstoragedata = new ArrayList<String>();
        //favstoragedata = new ArrayList<JSONObject>();
        //    cash=20000;
        //}
    }

    private void loadfavData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("favorites", null);
        //String json = sharedPreferences.getString("favorites", null);
        Type type = new TypeToken<ArrayList<JSONObject>>() {}.getType();
        favstoragedata = gson.fromJson(json, type);
        if (favstoragedata == null) {
            //favstoragedata = new ArrayList<String>();
            favstoragedata = new ArrayList<JSONObject>();
        }
    }

    private void clearfavData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        favstoragedata=new ArrayList<JSONObject>();
        String json = gson.toJson(favstoragedata);
        editor.putString("favorites", json);
        //editor.putString(dtype, json);
        editor.apply();
    }

    private void savefavData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(favstoragedata);
        editor.putString("favorites", json);
        //editor.putString(dtype, json);
        editor.apply();
    }

    private void clearpoData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        pofoliostoragedata=new ArrayList<JSONObject>();
        String json = gson.toJson(pofoliostoragedata);
        editor.putString("portfolio", json);
        //editor.putString(dtype, json);
        editor.apply();
    }

    private void loadpoData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("portfolio", null);
        //String json = sharedPreferences.getString("favorites", null);
        Type type = new TypeToken<ArrayList<JSONObject>>() {}.getType();
        pofoliostoragedata = gson.fromJson(json, type);
        if (pofoliostoragedata == null) {
            //favstoragedata = new ArrayList<String>();
            pofoliostoragedata = new ArrayList<JSONObject>();
        }
    }

    private void savepoData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(pofoliostoragedata);
        editor.putString("portfolio", json);
        //editor.putString(dtype, json);
        editor.apply();
    }

    private void favinfohttpreq(String requrl){

        favinfoGroup =new ArrayList<ArrayList<String> >();
        //RequestQueue queue = Volley.newRequestQueue(this);
        if (favtickers.size()!=0){
            // prepare the Request
            JsonArrayRequest getRequest = new JsonArrayRequest(Request.Method.GET, requrl, null,
                    new Response.Listener<JSONArray >()
                    {
                        @Override
                        public void onResponse(JSONArray  response) {
                            Log.d("Companyinfo_Response", response.toString());
                            favinfo=response;

                            //titleticker.setText(companyinfo.getString("ticker"));
                            //companyname.setText(companyinfo.getString("name"));
                            //aboutcon.setText(companyinfo.getString("description"));
                            //System.out.println("response:"+favinfo);

                            //favinfoGroup =new ArrayList<ArrayList<String> >();

                            //check if ticker in fav in porfolio too
                            for (int i=0;i<favtickers.size();i++){
                                ArrayList<String> favitem=new ArrayList<String>();
                                String itemticker=favtickers.get(i);

                                for (int j=0;j<favinfo.length();j++){
                                    JSONObject jobject= null;
                                    try {
                                        jobject = favinfo.getJSONObject(j);
                                        String curticker=jobject.getString("ticker");
                                        if (itemticker.equals(curticker)){
                                            favitem.add(itemticker);
                                            // if not in porfolio
                                            if (!potickerquantity.containsKey(itemticker)) {
                                                favitem.add(favtickercompname.get(itemticker));
                                            }
                                            else{
                                                favitem.add(String.valueOf(potickerquantity.get(itemticker))+" shares");
                                            }

                                            String newlast=jobject.getString("last");
                                            String newlastm=df.format(Double.parseDouble(newlast));
                                            favitem.add(newlastm);
                                            double change=Double.parseDouble(jobject.getString("last"))-Double.parseDouble(jobject.getString("prevClose"));
                                            String strchange=df.format(change);
                                            favitem.add(strchange);
                                            //String strchangem=strchange.substring(1);
                                            break;
                                        }

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }

                                favinfoGroup.add(favitem);
                            }

                            System.out.println("favGroup:"+favinfoGroup);
                            System.out.println("refresh-fav:"+favinfoGroup);

                            favGroup=findViewById(R.id.fav_group);
                            favadapter=new favadapter(MainActivity.this, favinfoGroup);
                            favlayoutManagerGroup=new LinearLayoutManager(MainActivity.this);
                            favGroup.setLayoutManager(favlayoutManagerGroup);
                            favGroup.setAdapter(favadapter);

                            // swip and reorder helper
                            //ItemTouchHelper itemTouchHelper=new ItemTouchHelper(simpleCallback);
                            itemTouchHelper.attachToRecyclerView(favGroup);

                            // will get portfolio url and check if ticker in fav in porfolio too ========
                            //priceinfohttpreq("https://siriusangularnojsapp.wl.r.appspot.com/price/"+ticker);
                            String porequrl="https://siriusangularnojsapp.wl.r.appspot.com/price/"+poalltickersstr;
                            poinfohttpreq(porequrl);

                            // dismiss spinner
                            //mainLayout1.setVisibility(View.INVISIBLE);
                            //mainLayout2.setVisibility(View.VISIBLE);

                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d("Error.Response", error.toString());
                        }
                    }
            );
            // add it to the RequestQueue
            Volley.newRequestQueue(getApplicationContext()).add(getRequest);
        }
        else{
            System.out.println("refresh-fav:"+favinfoGroup);

            favGroup=findViewById(R.id.fav_group);
            favadapter=new favadapter(MainActivity.this, favinfoGroup);
            favlayoutManagerGroup=new LinearLayoutManager(MainActivity.this);
            favGroup.setLayoutManager(favlayoutManagerGroup);
            favGroup.setAdapter(favadapter);

            // swip and reorder helper
            //ItemTouchHelper itemTouchHelper=new ItemTouchHelper(simpleCallback);
            itemTouchHelper.attachToRecyclerView(favGroup);

            // will get portfolio url and check if ticker in fav in porfolio too ========
            //priceinfohttpreq("https://siriusangularnojsapp.wl.r.appspot.com/price/"+ticker);
            String porequrl="https://siriusangularnojsapp.wl.r.appspot.com/price/"+poalltickersstr;
            poinfohttpreq(porequrl);
        }


    }

    ItemTouchHelper.SimpleCallback simpleCallback=new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN, ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            int fromPos=viewHolder.getAdapterPosition();
            int toPos=target.getAdapterPosition();

            Collections.swap(favstoragedata, fromPos,toPos );
            Collections.swap(favtickers, fromPos,toPos );
            Collections.swap(favinfoGroup, fromPos,toPos );
            savefavData();
            favadapter.notifyItemMoved(fromPos, toPos);
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            int position= viewHolder.getAdapterPosition();

            switch (direction){
                case ItemTouchHelper.LEFT:
                    favstoragedata.remove(position);
                    favtickers.remove(position);
                    favalltickersstr=android.text.TextUtils.join(",", favtickers);
                    favinfoGroup.remove(position);
                    savefavData();
                    favadapter.notifyItemRemoved(position);
                    break;
            }
        }

        @Override
        public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
            new RecyclerViewSwipeDecorator.Builder(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
                    .addSwipeLeftBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.red))
                    .addSwipeLeftActionIcon(R.drawable.ic_delete)
                    .create()
                    .decorate();

            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
        }

        @Override
        public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int actionState){
            if (actionState!=ItemTouchHelper.ACTION_STATE_IDLE){
                if (viewHolder instanceof RecyclerView.ViewHolder){
                    viewHolder.itemView.findViewById(R.id.back_fav_item).setBackgroundColor(Color.GRAY);
                }
            }
            super.onSelectedChanged(viewHolder, actionState);
        }

        @Override
        public void clearView(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder){
            super.clearView(recyclerView, viewHolder);
            viewHolder.itemView.findViewById(R.id.back_fav_item).setBackgroundColor(Color.WHITE);
        }


    };


    private void poinfohttpreq(String requrl){
        networth = cash;
        poinfoGroup = new ArrayList<ArrayList<String>>();

        //RequestQueue queue = Volley.newRequestQueue(this);
        if (pofoliostoragedata.size()!=0) {
            // prepare the Request
            JsonArrayRequest getRequest = new JsonArrayRequest(Request.Method.GET, requrl, null,
                    new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            Log.d("BoughtCompanyinfo_Response", response.toString());
                            poinfo = response;



                            for (int i = 0; i < potickers.size(); i++) {
                                ArrayList<String> poitem = new ArrayList<String>();
                                String itemticker = potickers.get(i);

                                for (int j = 0; j < poinfo.length(); j++) {
                                    JSONObject jobject = null;
                                    try {
                                        jobject = poinfo.getJSONObject(j);
                                        String curticker = jobject.getString("ticker");
                                        if (itemticker.equals(curticker)) {
                                            poitem.add(itemticker);
                                            poitem.add(String.valueOf(potickerquantity.get(itemticker)) + " shares");

                                            String newlast = jobject.getString("last");
                                            Double newlastd = Double.parseDouble(newlast);
                                            String newlastm = df.format(newlastd);
                                            poitem.add(newlastm);
                                            networth += newlastd * potickerquantity.get(itemticker);
                                            double change = Double.parseDouble(jobject.getString("last")) - Double.parseDouble(jobject.getString("prevClose"));
                                            String strchange = df.format(change);
                                            poitem.add(strchange);
                                            //String strchangem=strchange.substring(1);
                                            break;
                                        }

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }

                                poinfoGroup.add(poitem);
                            }

                            System.out.println("poGroup:" + poinfoGroup + df.format(networth));
                            System.out.println("refresh-portfolio:" + poinfoGroup + df.format(networth));

                            networthtext = (TextView) findViewById(R.id.networth);
                            networthtext.setText(df.format(networth));

                            poGroup = findViewById(R.id.po_group);
                            //poadapter=new poadapter(MainActivity.this, poinfoGroup);

                            poadapter = new poadapter(MainActivity.this, poinfoGroup);
                            polayoutManagerGroup = new LinearLayoutManager(MainActivity.this);
                            poGroup.setLayoutManager(polayoutManagerGroup);
                            poGroup.setAdapter(poadapter);


                            // swip and reorder helper
                            //ItemTouchHelper poitemTouchHelper=new ItemTouchHelper(posimpleCallback);
                            poitemTouchHelper.attachToRecyclerView(poGroup);


                            // dismiss spinner
                            mainLayout1.setVisibility(View.INVISIBLE);
                            mainLayout2.setVisibility(View.VISIBLE);

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d("Error.Response", error.toString());
                        }
                    }
            );
            // add it to the RequestQueue
            Volley.newRequestQueue(getApplicationContext()).add(getRequest);
        }
        else{
            System.out.println("poGroup:" + poinfoGroup + df.format(networth));
            System.out.println("refresh-portfolio:" + poinfoGroup + df.format(networth));

            networthtext = (TextView) findViewById(R.id.networth);
            networthtext.setText(df.format(networth));
            System.out.println("refresh-portfolio-work:" + poinfoGroup + df.format(networth));

            poGroup = findViewById(R.id.po_group);
            //poadapter=new poadapter(MainActivity.this, poinfoGroup);

            poadapter = new poadapter(MainActivity.this, poinfoGroup);
            polayoutManagerGroup = new LinearLayoutManager(MainActivity.this);
            poGroup.setLayoutManager(polayoutManagerGroup);
            poGroup.setAdapter(poadapter);


            // swip and reorder helper
            //ItemTouchHelper poitemTouchHelper=new ItemTouchHelper(posimpleCallback);
            poitemTouchHelper.attachToRecyclerView(poGroup);


            // dismiss spinner
            mainLayout1.setVisibility(View.INVISIBLE);
            mainLayout2.setVisibility(View.VISIBLE);

        }

    }

    ItemTouchHelper.SimpleCallback posimpleCallback=new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN,0) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            int fromPos=viewHolder.getAdapterPosition();
            int toPos=target.getAdapterPosition();

            Collections.swap(pofoliostoragedata, fromPos,toPos );
            Collections.swap(potickers, fromPos,toPos );
            poalltickersstr=android.text.TextUtils.join(",", potickers);
            Collections.swap(poinfoGroup, fromPos,toPos );
            savepoData();
            poadapter.notifyItemMoved(fromPos, toPos);
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
        }

        @Override
        public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int actionState){
            if (actionState!=ItemTouchHelper.ACTION_STATE_IDLE){
                if (viewHolder instanceof RecyclerView.ViewHolder){
                    viewHolder.itemView.findViewById(R.id.back_po_item).setBackgroundColor(Color.GRAY);
                }
            }
            super.onSelectedChanged(viewHolder, actionState);
        }

        @Override
        public void clearView(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder){
            super.clearView(recyclerView, viewHolder);
            viewHolder.itemView.findViewById(R.id.back_po_item).setBackgroundColor(Color.WHITE);
        }

    };



}