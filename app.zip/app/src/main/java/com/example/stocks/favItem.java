package com.example.stocks;

public class favItem {
    private String mticker;
    private String mcompanyname;

    public favItem(String ticker, String companyname) {
        mticker = ticker;
        mcompanyname = companyname;
    }
    public String getLine1() {
        return mticker;
    }
    public String getLine2() {
        return mcompanyname;
    }
}
