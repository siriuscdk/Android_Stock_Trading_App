package com.example.stocks;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class favadapter extends RecyclerView.Adapter<favadapter.ViewHolder>{
    //Initalize cativity and array list
    private Activity activity;
    ArrayList<ArrayList<String>> arrayListGroup;
    //ArrayList<String> arrayListGroup;

    //Create constructor
    favadapter(Activity activity, ArrayList<ArrayList<String>> arrayListGroup){
        this.activity=activity;
        this.arrayListGroup=arrayListGroup;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fav_item, parent, false);
        return new favadapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Set group name on Textview
        //holder.favticker.setText(arrayListGroup.get(position));
        String curticker=arrayListGroup.get(position).get(0);
        holder.favticker.setText(curticker);
        holder.favlast.setText(arrayListGroup.get(position).get(2));
        holder.favcompanyname.setText(arrayListGroup.get(position).get(1));
        //holder.favchange.setText(arrayListGroup.get(position).get(3));

        double change=Double.parseDouble(arrayListGroup.get(position).get(3));
        String changestr=String.valueOf(Math.abs(change));
        holder.favchange.setText(changestr);
        if (change>0){
            holder.favchange.setTextColor(Color.parseColor("#319C5E"));
            holder.favchange.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_up_trend, 0, 0, 0);
        }
        else if (change<0){
            holder.favchange.setTextColor(Color.parseColor("#9B4049"));
            holder.favchange.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_down_trend, 0, 0, 0);
        };

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // open another activity on item click
                Intent intent= new Intent(activity, detailactivity.class);
                intent.putExtra("ticker",curticker);
                //startActivity(intent);
                activity.startActivityForResult(intent, 2);
            }
        });



    }

    @Override
    public int getItemCount() {
        return arrayListGroup.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //Initialize variable
        TextView favticker;
        TextView favlast;
        TextView favcompanyname;
        TextView favchange;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            favticker=itemView.findViewById(R.id.fav_ticker);
            favlast=itemView.findViewById(R.id.favitem_lastprice);
            favcompanyname=itemView.findViewById(R.id.favitem_companyname);
            favchange=itemView.findViewById(R.id.favitem_change);
        }
    }
}
