package com.example.stocks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;

public class detailactivity extends AppCompatActivity {

    private static DecimalFormat df = new DecimalFormat("0.00");

    private androidx.appcompat.widget.Toolbar detailtoolbar;

    View Layout1;
    View Layout2;
    View Layout3;
    MenuItem emptystar;
    MenuItem filledstar;

    ArrayList<JSONObject> favstoragedata;
    boolean favthisticker;

    ArrayList<JSONObject> pofoliostoragedata;
    boolean boughtthisticker;
    double boughtquantity;
    int idxinstorage;

    float cash;
    double inputnumd;
    double totval;
    Dialog tradedialog;
    boolean buysucc;
    boolean sellsucc;

    String ticker;
    JSONObject companyinfo;
    JSONArray priceinfo;
    JSONArray newsinfo;

    TextView titleticker;
    String companynamestr;
    TextView companyname;
    TextView lastprice;
    double change;
    TextView changeview;
    double newlast;

    TextView statstitle;
    TextView portfoliotitle;
    TextView abouttitle;
    TextView aboutcon;
    TextView showmore;


    TextView allnewstitle;


    WebView highchartview;
    WebView highchartviewtest;

    TextView pofocon1;
    TextView pofocon2;
    Button tradebutton;

    GridView gridView;
    ArrayAdapter<String> statsadapter;
    ArrayList<String> statsdata = new ArrayList<>();

    //static final String[] statsdata = new String[] {"A", "B", "C", "D", "E","F", "G"};

    SimpleDateFormat dfdate = new SimpleDateFormat("yyyy-MM-dd");

    RecyclerView newsGroup;
    //ArrayList<String> arrayListGroup;
    ArrayList<ArrayList<String>> arrayListGroup;
    LinearLayoutManager layoutManagerGroup;
    newsadapter newsadapter;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailactivity);


        //set toolbar
        detailtoolbar=findViewById(R.id.mydetailToolbar);
        detailtoolbar.setTitle("Stocks");
        setSupportActionBar(detailtoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        // control spinner
        Layout1=findViewById(R.id.Layout1);
        Layout1.setVisibility(View.VISIBLE);

        Layout2=findViewById(R.id.Layout2);
        Layout2.setVisibility(View.INVISIBLE);

        Layout3=findViewById(R.id.Layout3);
        Layout3.setVisibility(View.INVISIBLE);

        // get ticker from search
        Intent intent=getIntent();
        ticker=intent.getStringExtra("ticker");

        /*if (ticker.indexOf("-")!=-1){
            ticker=ticker.substring(0,ticker.indexOf("-")-1);
        }
        Log.d("sendmysearch", ticker);*/



        //send multiple http req

        titleticker = (TextView)findViewById(R.id.titleticker);
        titleticker.setTextColor(Color.BLACK);
        companyname=(TextView)findViewById(R.id.companyname);
        lastprice=(TextView)findViewById(R.id.lastprice);
        lastprice.setTextColor(Color.BLACK);
        changeview=(TextView)findViewById(R.id.change);

        statstitle=(TextView)findViewById(R.id.statstitle);
        statstitle.setTextColor(Color.BLACK);
        portfoliotitle=(TextView)findViewById(R.id.portfoliotitle);
        portfoliotitle.setTextColor(Color.BLACK);
        abouttitle=(TextView)findViewById(R.id.abouttitle);
        abouttitle.setTextColor(Color.BLACK);
        aboutcon=(TextView)findViewById(R.id.aboutcon);
        aboutcon.setTextColor(Color.BLACK);
        allnewstitle=(TextView)findViewById(R.id.newstitle);
        allnewstitle.setTextColor(Color.BLACK);

        // set up highchart

        highchartview=(WebView) findViewById(R.id.hightchart);
        highchartview.getSettings().setJavaScriptEnabled(true);
        //highchartview.setBackgroundColor(Color.YELLOW);
        highchartview.loadUrl("file:///android_asset/myweb.html?ticker="+ticker.toUpperCase());
        //highchartview.loadUrl("file:///android_asset/highcharts.html");






        // set up grid view stats
        gridView = (GridView) findViewById(R.id.stats);
        statsadapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1);

        gridView.setAdapter(statsadapter);

        companyinfohttpreq("https://siriusangularnojsapp.wl.r.appspot.com/company/"+ticker);

        // portofolio

        loadcash();
        System.out.println("portfolio cash:"+cash);

        pofocon1=(TextView)findViewById(R.id.portfoliocon1);
        pofocon2=(TextView)findViewById(R.id.portfoliocon2);
        tradebutton=findViewById(R.id.tradebutton);

        loadpoData();
        System.out.println("portfolio:"+pofoliostoragedata);
        checkifbought();
        updateportfoliotext();

        tradebutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                tradedialog=new Dialog(detailactivity.this);
                tradedialog.setContentView(R.layout.buy_dialog);

                TextView buydialogtitle=tradedialog.findViewById(R.id.buydialogtitle);
                EditText inputnumshares=(EditText)tradedialog.findViewById(R.id.inputnumshares);
                inputnumshares.setHint("0");
                //String inputnum=inputnumshares.getText().toString();
                TextView computetot=tradedialog.findViewById(R.id.computetot);
                TextView buydialogfooter=tradedialog.findViewById(R.id.buydialogfooter);

                computetot.setText(0+" x $"+newlast+"/share=$ 0.00");

                buydialogtitle.setText("Trade "+companynamestr+" shares");

                inputnumshares.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        String inputnum=inputnumshares.getText().toString();
                        if (inputnum.length()!=0){
                            inputnumd=Double.parseDouble(inputnum);
                            totval=inputnumd*newlast;
                            String totvalstr=df.format(totval);
                            computetot.setText(inputnum+" x $"+newlast+"/share=$"+totvalstr);
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                //computetot.setText(inputnum+" x $"+lastprice+"/share=");

                buydialogfooter.setText("$"+cash+" available to buy "+ticker.toUpperCase());

                //update portfolio
                //update cash
                // add to portfolio (if none), remove from portfolio (sell all shares of this ticker)
                // use two bool val to decide which dialog to show
                // update portfolio text
                Button buytton=tradedialog.findViewById(R.id.buybutton);
                buytton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loadcash();
                        if (totval>0 && totval<cash){
                            buysucc=true;
                        }else{
                            buysucc=false;
                        }
                        //System.out.println("portfolio buy:"+totval+"cash:"+cash+buysucc);
                        if (buysucc){
                            //update cash
                            cash-=totval;
                            savecash();
                            //update portfolio
                            loadpoData();
                            checkifbought();

                            if (boughtthisticker){
                                JSONObject curobj=pofoliostoragedata.get(idxinstorage);
                                boughtquantity+=inputnumd;
                                try {
                                    curobj.put("quantity",boughtquantity);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                            else{ //never bought this stock
                                boughtquantity=inputnumd;
                                boughtthisticker=true;
                                //idxinstorage=pofoliostoragedata.size();

                                JSONObject newobj=new JSONObject();
                                try {
                                    newobj.put("ticker", ticker.toUpperCase());
                                    newobj.put("quantity", boughtquantity);
                                    pofoliostoragedata.add(newobj);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }

                            savepoData();

                            Dialog dialog=new Dialog(detailactivity.this);
                            dialog.setContentView(R.layout.buysuc_dialog);

                            //update portfolio text
                            updateportfoliotext();


                            TextView boughtsuctext=dialog.findViewById(R.id.boughtsuctext);
                            Button boughtsucbutton=dialog.findViewById(R.id.boughtsucbutton);

                            boughtsuctext.setText("You have successfully bought "+inputnumd+" shares of "+ticker.toUpperCase());
                            boughtsucbutton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });

                            dialog.show();
                            tradedialog.dismiss();



                        }else {
                            //show fail digloa/toast
                            if(inputnumd<=0){
                                Toast.makeText(getApplicationContext(), "Cannot buy less than 0 shares",
                                        Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(getApplicationContext(), "Not enough money to buy",
                                        Toast.LENGTH_SHORT).show();
                            }
                            //Dialog dialog=new Dialog(detailactivity.this);
                            //dialog.setContentView(R.layout.buyfail_dialog);
                            //dialog.show();
                            //tradedialog.dismiss();
                        }
                    }
                });

                Button sellbutton=tradedialog.findViewById(R.id.sellbutton);
                sellbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loadpoData();
                        checkifbought();

                        if (boughtquantity!=0 && boughtquantity>=inputnumd && inputnumd>0){
                            sellsucc=true;
                        }
                        else{
                            sellsucc=false;
                        }

                        if (sellsucc){
                            //update cash
                            loadcash();
                            cash+=totval;
                            savecash();

                            //update portfolio
                            if (boughtquantity==inputnumd){ //sell all shares of this ticker
                                pofoliostoragedata.remove(idxinstorage);
                                boughtthisticker=false;
                                boughtquantity=0;
                            }
                            else{//boughtquantity<inputnumd
                                boughtquantity-=inputnumd;

                                JSONObject curobj=pofoliostoragedata.get(idxinstorage);
                                try {
                                    curobj.put("quantity",boughtquantity);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            savepoData();

                            Dialog dialog=new Dialog(detailactivity.this);
                            dialog.setContentView(R.layout.sellsuc_dialog);

                            //update portfolio text
                            updateportfoliotext();

                            TextView boughtsuctext=dialog.findViewById(R.id.soldsuctext);
                            Button boughtsucbutton=dialog.findViewById(R.id.soldsucbutton);

                            boughtsuctext.setText("You have successfully sold "+inputnumd+" shares of "+ticker.toUpperCase());
                            boughtsucbutton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });

                            dialog.show();
                            tradedialog.dismiss();

                        }
                        else {
                            //show fail diglog/ toast
                            //Dialog dialog=new Dialog(detailactivity.this);
                            //dialog.setContentView(R.layout.sellfail_dialog);
                            //dialog.show();
                            //tradedialog.dismiss();
                            if(inputnumd<=0){
                                Toast.makeText(getApplicationContext(), "Cannot sell less than 0 shares",
                                        Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(getApplicationContext(), "‘Not enough shares to sell",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }



                    }
                });


                tradedialog.show();
            }
        });


        showmore=(TextView)findViewById(R.id.showmore);
        showmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (showmore.getText().toString().equalsIgnoreCase("Showmore..."))
                {
                    aboutcon.setMaxLines(Integer.MAX_VALUE);//your TextView
                    showmore.setText("Showless");
                }
                else
                {
                    aboutcon.setMaxLines(3);//your TextView
                    showmore.setText("Showmore...");
                }
            }
        });

        //
        newsGroup=findViewById(R.id.news_group);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.detailmenu, menu);

        // set star

        emptystar=menu.findItem(R.id.emptystar);
        filledstar=menu.findItem(R.id.filledstar);

        // check local storage
        loadfavData();
        System.out.println("details:"+favstoragedata);
        /*if (favstoragedata.contains(ticker.toUpperCase())){
            emptystar.setVisible(false);
            filledstar.setVisible(true);
        }else{
            emptystar.setVisible(true);
            filledstar.setVisible(false);
        }*/

        for (int i=0;i<favstoragedata.size();i++){
            JSONObject curobj=favstoragedata.get(i);
            try {
                if (curobj.getString("ticker").equals(ticker.toUpperCase())){
                    favthisticker=true;
                    break;
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if (favthisticker){
            emptystar.setVisible(false);
            filledstar.setVisible(true);
        }else{
            emptystar.setVisible(true);
            filledstar.setVisible(false);
        }


        emptystar.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                emptystar.setVisible(false);
                filledstar.setVisible(true);
                return true;
            }
        });

        emptystar.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Toast.makeText(getApplicationContext(), '"'+ticker.toUpperCase()+'"'+" was added to favorites",
                        Toast.LENGTH_SHORT).show();

                // store in local storage
                loadfavData();
                //favstoragedata.add(new favItem(ticker.toUpperCase(), companynamestr));
                JSONObject newobj=new JSONObject();
                try {
                    newobj.put("ticker", ticker.toUpperCase());
                    newobj.put("companyname", companynamestr);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                favstoragedata.add(newobj);
                savefavData();

                emptystar.setVisible(false);
                filledstar.setVisible(true);
                return true;
            }
        });

        filledstar.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Toast.makeText(getApplicationContext(), '"'+ticker.toUpperCase()+'"'+" was removed from favorites",
                        Toast.LENGTH_SHORT).show();

                // remove from local storage
                loadfavData();
                //if (favstoragedata.contains(ticker.toUpperCase())){
                //    favstoragedata.remove(ticker.toUpperCase());
                //}
                ArrayList<JSONObject> newfavstoragedata = new ArrayList<JSONObject>();
                for (int i=0;i<favstoragedata.size();i++){
                    JSONObject curobj=favstoragedata.get(i);
                    try {
                        if (!curobj.getString("ticker").equals(ticker.toUpperCase())){
                            newfavstoragedata.add(curobj);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("new storage:"+newfavstoragedata);

                favstoragedata=newfavstoragedata;
                savefavData();

                filledstar.setVisible(false);
                emptystar.setVisible(true);
                return true;
            }
        });


        return true;
    }

    private void loadcash() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        cash=sharedPreferences.getFloat("cash", 0.0f);
        //if (cash == 0) {
            //favstoragedata = new ArrayList<String>();
            //favstoragedata = new ArrayList<JSONObject>();
        //    cash=20000;
        //}
    }

    private void savecash() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("cash", cash);
        editor.apply();
    }

    private void savefavData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(favstoragedata);
        editor.putString("favorites", json);
        //editor.putString(dtype, json);
        editor.apply();
    }

    private void loadfavData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("favorites", null);
        //String json = sharedPreferences.getString("favorites", null);
        Type type = new TypeToken<ArrayList<JSONObject>>() {}.getType();
        favstoragedata = gson.fromJson(json, type);
        if (favstoragedata == null) {
            //favstoragedata = new ArrayList<String>();
            favstoragedata = new ArrayList<JSONObject>();
        }
    }

    private void savepoData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(pofoliostoragedata);
        editor.putString("portfolio", json);
        //editor.putString(dtype, json);
        editor.apply();
    }

    private void loadpoData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("portfolio", null);
        //String json = sharedPreferences.getString("favorites", null);
        Type type = new TypeToken<ArrayList<JSONObject>>() {}.getType();
        pofoliostoragedata = gson.fromJson(json, type);
        if (pofoliostoragedata == null) {
            //favstoragedata = new ArrayList<String>();
            pofoliostoragedata = new ArrayList<JSONObject>();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        switch(item.getItemId()){
            case android.R.id.home:
                Intent intent=new Intent();
                setResult(2,intent);
                finish();
                //Intent intent= new Intent(detailactivity.this,MainActivity.class);
                //startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }




    private void companyinfohttpreq(String requrl){

        //RequestQueue queue = Volley.newRequestQueue(this);

        // prepare the Request
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, requrl, null,
                new Response.Listener<JSONObject >()
                {
                    @Override
                    public void onResponse(JSONObject  response) {
                        Log.d("Companyinfo_Response", response.toString());
                        companyinfo=response;

                        if (!companyinfo.has("detail")){
                            try {
                                titleticker.setText(companyinfo.getString("ticker"));
                                companynamestr=companyinfo.getString("name");
                                companyname.setText(companynamestr);
                                aboutcon.setText(companyinfo.getString("description"));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            priceinfohttpreq("https://siriusangularnojsapp.wl.r.appspot.com/price/"+ticker);
                            // dismiss spinner
                            //Layout1.setVisibility(View.INVISIBLE);
                            //Layout2.setVisibility(View.VISIBLE);
                            }
                        else{
                            emptystar.setVisible(false);
                            filledstar.setVisible(false);
                            Layout1.setVisibility(View.INVISIBLE);
                            Layout2.setVisibility(View.INVISIBLE);
                            Layout3.setVisibility(View.VISIBLE);
                        }

                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", error.toString());
                    }
                }
        );
        // add it to the RequestQueue
        Volley.newRequestQueue(getApplicationContext()).add(getRequest);

    }

    private void priceinfohttpreq(String requrl){

        //RequestQueue queue = Volley.newRequestQueue(this);

        // prepare the Request
        JsonArrayRequest getRequest = new JsonArrayRequest(Request.Method.GET, requrl, null,
                new Response.Listener<JSONArray >()
                {
                    @Override
                    public void onResponse(JSONArray  response) {
                        Log.d("Companyinfo_Response", response.toString());
                        priceinfo=response;

                        try {
                            newlast=Double.parseDouble(priceinfo.getJSONObject(0).getString("last"));
                            String newlastm=df.format(newlast);
                            lastprice.setText("$"+newlastm);

                            change=Double.parseDouble(priceinfo.getJSONObject(0).getString("last"))-Double.parseDouble(priceinfo.getJSONObject(0).getString("prevClose"));
                            String strchange=df.format(change);
                            String strchangem=strchange.substring(1);
                            Log.d("strchange", strchangem);
                            if (change>0){
                                changeview.setTextColor(Color.parseColor("#319C5E"));
                                changeview.setText("+$"+strchange);
                            }
                            else if (change<0){
                                changeview.setTextColor(Color.parseColor("#9B4049"));
                                changeview.setText("-$"+strchangem);
                            }else{
                                changeview.setText("$"+strchange);
                            };

                            updateportfoliotext();
                            // stats data
                            //ArrayList<String> statsdata = new ArrayList<>();
                            statsdata.clear();
                            double curprice=Double.parseDouble(priceinfo.getJSONObject(0).getString("last"));
                            String curpricestr=df.format(curprice);
                            statsdata.add("Current Price:"+curpricestr);
                            double curlow=Double.parseDouble(priceinfo.getJSONObject(0).getString("low"));
                            String curlowstr=df.format(curlow);
                            statsdata.add("Low:"+curlowstr);
                            if (priceinfo.getJSONObject(0).getString("bidPrice")!="null"){
                                double bidprice=Double.parseDouble(priceinfo.getJSONObject(0).getString("bidPrice"));
                                String bidpricestr=df.format(bidprice);
                                statsdata.add("Bid Price:"+bidpricestr);}
                            else{
                                statsdata.add("Bid Price: 0.0");
                            };
                            double openprice=Double.parseDouble(priceinfo.getJSONObject(0).getString("open"));
                            String openpricestr=df.format(openprice);
                            statsdata.add("OpenPrice:"+openpricestr);
                            if (priceinfo.getJSONObject(0).getString("mid")!="null"){
                                double curmid=Double.parseDouble(priceinfo.getJSONObject(0).getString("mid"));
                                String curmidstr=df.format(curmid);
                                statsdata.add("Mid:"+curmidstr);
                            }
                            else {
                                statsdata.add("Mid: 0.0");
                            };
                            double curhigh=Double.parseDouble(priceinfo.getJSONObject(0).getString("high"));
                            String curhighstr=df.format(curhigh);
                            statsdata.add("High:"+curhighstr);
                            double curvol=Double.parseDouble(priceinfo.getJSONObject(0).getString("volume"));
                            String curvolstr=df.format(curvol);
                            statsdata.add("Volume:"+curvolstr);

                            //  connect to gridview
                            //statsadapter.clear();
                            //System.out.println(statsdata);
                            statsadapter.addAll(statsdata);
                            statsadapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        newsinfohttpreq("https://siriusangularnojsapp.wl.r.appspot.com/news/"+ticker);

                        // dismiss spinner
                        //Layout1.setVisibility(View.INVISIBLE);
                        //Layout2.setVisibility(View.VISIBLE);
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", error.toString());
                    }
                }
        );
        // add it to the RequestQueue
        Volley.newRequestQueue(getApplicationContext()).add(getRequest);

    }

    private void newsinfohttpreq(String requrl){

        //RequestQueue queue = Volley.newRequestQueue(this);

        // prepare the Request
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, requrl, null,
                new Response.Listener<JSONObject >()
                {
                    @Override
                    public void onResponse(JSONObject  response) {
                        Log.d("Newsinfo_Response", response.toString());
                        try {
                            newsinfo=response.getJSONArray("articles");

                            arrayListGroup =new ArrayList<ArrayList<String> >();
                            for (int i=0;i<newsinfo.length();i++){
                                JSONObject jobject= newsinfo.getJSONObject(i);
                                String name=jobject.getJSONObject("source").getString("name");
                                String title=jobject.getString("title");
                                String imageurl=jobject.getString("urlToImage");
                                String url=jobject.getString("url");
                                if (name!="null" && title!="null" && imageurl!="null") {
                                    ArrayList<String> a = new ArrayList<String>();

                                    String curdatestr = dfdate.format(new Date());
                                    String predatestr=jobject.getString("publishedAt").substring(0,10);
                                    LocalDate dateBefore = LocalDate.parse(curdatestr);
                                    LocalDate dateAfter = LocalDate.parse(predatestr);

                                    long noOfDaysBetween = ChronoUnit.DAYS.between(dateAfter, dateBefore);
                                    //System.out.println(noOfDaysBetween);

                                    a.add(name+ "  " +noOfDaysBetween+ " days ago");
                                    a.add(title);
                                    a.add(imageurl);
                                    a.add(url);
                                    arrayListGroup.add(a);
                                }
                            }
                            //System.out.println(arrayListGroup);
                            //newsadapter.notifyDataSetChanged();

                            //newsadapter=new newsadapter(detailactivity.this, arrayListGroup);
                            newsadapter=new newsadapter(detailactivity.this, arrayListGroup);
                            //initalize layout manager
                            layoutManagerGroup=new LinearLayoutManager(detailactivity.this);
                            //Set layout manager
                            newsGroup.setLayoutManager(layoutManagerGroup);
                            //Set adapter
                            newsGroup.setAdapter(newsadapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }




                        // dismiss spinner
                        Layout1.setVisibility(View.INVISIBLE);
                        Layout2.setVisibility(View.VISIBLE);



                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", error.toString());
                    }
                }
        );
        // add it to the RequestQueue
        Volley.newRequestQueue(getApplicationContext()).add(getRequest);

    }

    private void updateportfoliotext(){
        if (boughtthisticker){
            pofocon1.setText("Shares owned:"+boughtquantity);
            pofocon2.setText("Market Value: $"+df.format(boughtquantity*newlast));
        }else{
            boughtquantity=0;
            pofocon1.setText("You have 0 shares of "+ticker.toUpperCase()+'.');
            pofocon2.setText("Start trading!");
        }

    }

    private void checkifbought(){
        for (int i=0;i<pofoliostoragedata.size();i++){
            JSONObject curobj=pofoliostoragedata.get(i);
            try {
                if (curobj.getString("ticker").equals(ticker.toUpperCase())){
                    boughtthisticker=true;
                    boughtquantity=curobj.getDouble("quantity");
                    idxinstorage=i;
                    break;
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if (!boughtthisticker){
            boughtquantity=0;
        }
    }



}